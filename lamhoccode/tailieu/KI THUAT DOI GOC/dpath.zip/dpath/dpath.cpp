#include <bits/stdc++.h>
using namespace std;
#define thn 0969156825
const int N = 100001;
int n, D, a[N], F[N][1001];
long long int KQ;
vector<int> KE[N];

void DFS(int u,int p) {
  F[u][0]=1;
  for (auto v : KE[u]) {
    if (v!=p) {
      DFS(v,u);
      for (int k=1; k<=D; k++)
        F[u][k]+=F[v][k-1];
    }
  }
}

void doigoc(int u, int p) {
  KQ += F[u][D];
  int k;
  for (auto v : KE[u]) {
    if (v!=p) {
      for (k=1; k<=D; k++)
        F[u][k]-=F[v][k-1];
      for (k=1; k<=D; k++)
        F[v][k]+=F[u][k-1];
      doigoc(v,u);
      for (k=1; k<=D; k++)
        F[v][k]-=F[u][k-1];
      for (k=1; k<=D; k++)
        F[u][k]+=F[v][k-1];
    }
  }
}

void xuli() {
  memset(F, 0,sizeof F);
  KQ=0;
  DFS(1,0);
  doigoc(1,0);
  cout<<KQ/2;
}

int main()
{
	ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
	freopen("DPATH.INP","r", stdin);
	freopen("DPATH.OUT","w", stdout);
	int x,y,i;
	cin>>n>>D;
	
	for (i=1; i<n; i++) {
	  cin>>x>>y;
	  KE[x].push_back(y);
	  KE[y].push_back(x);
	}
	xuli();
	return 0;
}
