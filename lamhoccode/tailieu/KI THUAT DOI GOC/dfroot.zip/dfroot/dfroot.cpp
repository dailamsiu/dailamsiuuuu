#include <bits/stdc++.h>
using namespace std;
#define thn 0969156825
const int N = 1000001;
int n, F[N], SIZE[N], KQ[N];
vector<int> KE[N];

void DFS(int u,int p) 
{ 
    F[u]=0;
    SIZE[u]=1;
    for (auto v : KE[u]) {
        if (v!=p) {
            DFS(v,u);
            SIZE[u]+=SIZE[v];
            F[u]+=F[v]+SIZE[v];
        }
    }
}


void doigoc(int u, int p) 
{
    KQ[u] = F[u];
    int Su, Sv, Fu, Fv;
    for (auto v : KE[u]) {
        if (v!=p) {
            Fu=F[u]; Su=SIZE[u];
            Fv=F[v]; Sv=SIZE[v];
            F[u]-=F[v]+SIZE[v];
            SIZE[u]-=SIZE[v];
            F[v]+=F[u]+SIZE[u];
            SIZE[v]+=SIZE[u];
            doigoc(v,u);
            F[u]=Fu; SIZE[u]=Su;
            F[v]=Fv; SIZE[v]=Sv;
        }
    }
}


void xuli() {
    DFS(1,0);
    doigoc(1,0);
    for (int u=1; u<=n; u++) cout<<KQ[u]<<endl;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    freopen("DFROOT.INP","r", stdin);
    freopen("DFROOT.OUT","w", stdout);
    int x,y,i;
    cin>>n;
    for (i=1; i<n; i++) {
        cin>>x>>y;
        KE[x].push_back(y);
        KE[y].push_back(x);
    }
    xuli();
    return 0;
}
