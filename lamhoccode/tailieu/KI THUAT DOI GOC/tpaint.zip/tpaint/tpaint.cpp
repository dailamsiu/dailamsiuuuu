#include <bits/stdc++.h>
using namespace std;
#define thn 0969156825
const int N = 200001;
int n;
long long int F[N], SIZE[N], KQ=0;
vector<int> KE[N];
 
void DFS(int u,int p) 
{ 
    F[u]=1;
    SIZE[u]=1;
    for (auto v : KE[u]) {
        if (v!=p) {
            DFS(v,u);
            SIZE[u]+=SIZE[v];
            F[u]+=F[v]+SIZE[v];
        }
    }
}
 
void doigoc(int u, int p) 
{
    KQ = max(KQ, F[u]);
    int Su, Sv, Fu, Fv;
    for (auto v : KE[u]) {
        if (v!=p) {
            Fu=F[u]; Su=SIZE[u];
            Fv=F[v]; Sv=SIZE[v];
            F[u]-=F[v]+SIZE[v];
            SIZE[u]-=SIZE[v];
            F[v]+=F[u]+SIZE[u];
            SIZE[v]+=SIZE[u];
            doigoc(v,u);
            F[u]=Fu; SIZE[u]=Su;
            F[v]=Fv; SIZE[v]=Sv;
        }
    }
}
 
void xuli() {
    DFS(1,0);
    doigoc(1,0);
    cout<<KQ;
}
 
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    freopen("TPAINT.INP","r", stdin);
    freopen("TPAINT.OUT","w", stdout);
    int x,y,i;
    cin>>n;
    for (i=1; i<n; i++) {
        cin>>x>>y;
        KE[x].push_back(y);
        KE[y].push_back(x);
    }
    xuli();
    return 0;
}